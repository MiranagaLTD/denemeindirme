package org.schabi.newpipe.database.playlist;

import org.schabi.newpipe.database.LocalItem;

public interface PlaylistLocalItem extends LocalItem {
    String getOrderingName();
}
