package com.zxmark.videodownloader.service;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.imobapp.videodownloaderforinstagram.R;
import com.zxmark.videodownloader.MainActivity;
import com.zxmark.videodownloader.MainApplication;
import com.zxmark.videodownloader.bean.WebPageStructuredData;
import com.zxmark.videodownloader.db.DBHelper;
import com.zxmark.videodownloader.db.DownloadContentItem;
import com.zxmark.videodownloader.db.DownloaderDBHelper;
import com.zxmark.videodownloader.downloader.DownloadingTaskList;
import com.zxmark.videodownloader.downloader.VideoDownloadFactory;
import com.zxmark.videodownloader.floatview.FloatViewManager;
import com.zxmark.videodownloader.util.ActivityManagerUtils;
import com.zxmark.videodownloader.util.DownloadUtil;
import com.zxmark.videodownloader.util.EventUtil;
import com.zxmark.videodownloader.util.Globals;
import com.zxmark.videodownloader.util.LogUtil;
import com.zxmark.videodownloader.util.NetWorkUtil;
import com.zxmark.videodownloader.widget.IToast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by fanlitao on 17/6/7.
 */

public class DownloadService extends Service {


    public static final String KAYDETMEYERI = "INSDownloader";
    public static final String DOWNLOAD_ACTION = "download_action";
    public static final String DOWNLOAD_PAGE_URL = "page_url";
    public static final String ACTION_CANCEL_ALL_NOTIFICATION = "cancel_all_notification";
    public static final String REQUEST_VIDEO_URL_ACTION = "request_video_url_action";
    public static final String REQUEST_DOWNLOAD_VIDEO_ACTION = "request_download_video_action";
    public static final String EXTRAS_FLOAT_VIEW = "extras_float_view";
    public static final String EXTRAS_FORCE_DOWNLOAD = "extras_force_download";
    public static final String DOWNLOAD_URL = "download_url";

    public static final int MSG_DOWNLOAD_SUCCESS = 0;
    public static final int MSG_DOWNLOAD_ERROR = 1;
    public static final int MSG_DOWNLOAD_START = 2;
    public static final int MSG_UPDATE_PROGRESS = 3;
    public static final int MSG_NOTIFY_DOWNLOADED = 4;
    public static final int MSG_HANDLE_SEND_ACTION = 5;
    public static final int MSG_REQUSET_URL_ERROR = 6;

    private NotificationManager mNotifyManager;

    private static final String NOTIFICATION_CHANNEL_SERVICE = "download-notification";

    private NotificationCompat.Builder mBuilder;
    private NotificationManager mNotificationManager;

    public static final int NOTIFICATION_ID_DOWNLOAD = 1000009;

    InterstitialAd interstitialAd;
    AdRequest adRequest;

    final RemoteCallbackList<IDownloadCallback> mCallbacks = new RemoteCallbackList<IDownloadCallback>();

    @Override
    public void onCreate() {
        super.onCreate();
        initNotification();
    }

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == MSG_DOWNLOAD_SUCCESS) {
                if (msg.obj != null) {
                    String pageURL = (String) msg.obj;
                    cancelNotification(pageURL);
                    boolean isExistURL = DownloaderDBHelper.SINGLETON.isExistPageURL(pageURL);
                    LogUtil.e("download", "isExistURL:" + isExistURL);
                    if (isExistURL) {
                        IToast.makeText(DownloadService.this, R.string.download_result_success, Toast.LENGTH_SHORT).show();
                        DownloadService.this.notifyDownloadFinished((String) msg.obj);

                    }
                }
            } else if (msg.what == MSG_DOWNLOAD_ERROR) {
                showADS();
                IToast.makeText(DownloadService.this, R.string.download_failed, Toast.LENGTH_SHORT).show();
            } else if (msg.what == MSG_DOWNLOAD_START) {
                String pageURL = (String) msg.obj;
                setNotificationContent(pageURL, "Start Downloading");
                DownloadService.this.notifyStartDownload((String) msg.obj);
            } else if (msg.what == MSG_UPDATE_PROGRESS) {
                //updateNotificationProgress((String) msg.obj, msg.arg1);
                DownloadService.this.notifyDownloadProgress((String) msg.obj, msg.arg2, msg.arg1);
            } else if (msg.what == MSG_NOTIFY_DOWNLOADED) {
                IToast.makeText(DownloadService.this, R.string.toast_downlaoded_video, Toast.LENGTH_SHORT).show();
                DownloadService.this.notifyReceiveNewTask(getString(R.string.toast_downlaoded_video));
            } else if (msg.what == MSG_HANDLE_SEND_ACTION) {
                if (msg.obj == null) {
                    IToast.makeText(DownloadService.this, R.string.spider_request_error, Toast.LENGTH_SHORT).show();
                }
                DownloadService.this.notifyReceiveNewTask((String) msg.obj);
            }
        }
    };
    public void initAds(){
        adRequest = new AdRequest.Builder().build();
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId("ca-app-pub-5625381619413371/8607887994");
        interstitialAd.loadAd(adRequest);
        interstitialAd.setAdListener(new AdListener(){
            @Override
            public void onAdClosed() {
                super.onAdClosed();
                loadADS();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                loadADS();
            }

            @Override
            public void onAdLeftApplication() {
                super.onAdLeftApplication();
                loadADS();
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
                loadADS();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
                loadADS();
            }
        });
        showADS();
    }

    public void loadADS(){
        if (!interstitialAd.isLoaded()){
            interstitialAd.loadAd(adRequest);
        }
    }

    public void showADS(){
        if (!interstitialAd.isLoaded()){
            interstitialAd.loadAd(adRequest);
        }else{
            interstitialAd.show();
        }
    }


    private void showFloatView() {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (DownloadingTaskList.SINGLETON.getFutureTask().size() == 0) {
                    FloatViewManager manager = FloatViewManager.getDefault();
                    manager.showFloatView();
                }
            }
        });

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            LogUtil.v("TL", "onHandleIntent:" + intent.getAction());
            DownloadUtil.checkDownloadBaseHomeDirectory();

            if (ACTION_CANCEL_ALL_NOTIFICATION.equals(intent.getAction())) {

                cancelAllNotification();
                return super.onStartCommand(intent, flags, startId);
            }
            if (DOWNLOAD_ACTION.equals(intent.getAction())) {
                final String url = intent.getStringExtra(Globals.EXTRAS);
                final String pageURL = intent.getStringExtra(DOWNLOAD_PAGE_URL);

                if (TextUtils.isEmpty(url)) {
                    return super.onStartCommand(intent, flags, startId);
                }
                DownloadContentItem item = DownloaderDBHelper.SINGLETON.getDownloadItemByPageURL(pageURL);
                final String homeDir = item.getTargetDirectory(url);
                DownloadingTaskList.SINGLETON.getExecutorService().execute(new Runnable() {
                    @Override
                    public void run() {
                        PowerfulDownloader.getDefault().startDownload(pageURL, 0, url, homeDir, new PowerfulDownloader.IPowerfulDownloadCallback() {
                            @Override
                            public void onStart(String path) {

                            }

                            @Override
                            public void onFinish(int statusCode, String pageURL, int filePositon, String path) {
                                mHandler.sendEmptyMessage(MSG_DOWNLOAD_SUCCESS);
                            }

                            @Override
                            public void onError(int errorCode) {

                            }

                            @Override
                            public void onProgress(String pageURL, int filePositon, String path, int progress) {

                            }
                        });
                    }
                });

            } else if (REQUEST_VIDEO_URL_ACTION.equals(intent.getAction())) {
                final String url = intent.getStringExtra(Globals.EXTRAS);
                if (TextUtils.isEmpty(url)) {
                    return super.onStartCommand(intent, flags, startId);
                }
                final boolean showFloatView = intent.getBooleanExtra(DownloadService.EXTRAS_FLOAT_VIEW, true);
                String pageHome = DownloaderDBHelper.SINGLETON.getDownloadedPageHomeByURL(url);
                final boolean forceDownload = intent.getBooleanExtra(DownloadService.EXTRAS_FORCE_DOWNLOAD, false);
                if (!forceDownload) {
                    if (pageHome != null && new File(pageHome).exists()) {
                        mHandler.sendEmptyMessage(MSG_NOTIFY_DOWNLOADED);
                        return super.onStartCommand(intent, flags, startId);
                    }
                }

                DownloadUtil.checkDownloadBaseHomeDirectory();
                DownloadingTaskList.SINGLETON.setHandler(mHandler);
                DownloadingTaskList.SINGLETON.getExecutorService().execute(new Runnable() {
                    @Override
                    public void run() {
                        DownloadContentItem downloadContentItem = null;
                        downloadContentItem = VideoDownloadFactory.getInstance().request(url);

                        if (downloadContentItem != null && downloadContentItem.getFileCount() > 0) {
                            EventUtil.getDefault().onEvent("download", "DownloadService.StartDownload:" + url);
                            if (showFloatView) {
                                showFloatView();
                            }
                            LogUtil.e("download", "startDownload:" + url + ":" + downloadContentItem.pageHOME);
                            String pageHome = DownloaderDBHelper.SINGLETON.getPageHomeByPageURL(url);
                            LogUtil.e("download", "startDownload:existHome=" + pageHome);
                            if (!TextUtils.isEmpty(pageHome)) {
                                downloadContentItem.pageHOME = pageHome;
                                File targetHome = new File(pageHome);
                                if (!targetHome.exists()) {
                                    targetHome.mkdir();
                                }
                                downloadContentItem.pageStatus = DownloadContentItem.PAGE_STATUS_DOWNLOADING;
                            }
                            DownloaderDBHelper.SINGLETON.saveNewDownloadTask(downloadContentItem);
                            if (!forceDownload) {
                                mHandler.obtainMessage(MSG_DOWNLOAD_START, downloadContentItem.pageURL).sendToTarget();
                            }
                            DownloadingTaskList.SINGLETON.addNewDownloadTask(url, downloadContentItem);
                        } else {
                            mHandler.sendEmptyMessage(MSG_HANDLE_SEND_ACTION);
                        }
                    }
                });


            } else if (REQUEST_DOWNLOAD_VIDEO_ACTION.equals(intent.getAction())) {
                String url = intent.getStringExtra(Globals.EXTRAS);
                if (DownloaderDBHelper.SINGLETON.isExistDownloadedPageURL(url)) {
                    mHandler.sendEmptyMessage(MSG_NOTIFY_DOWNLOADED);
                    return super.onStartCommand(intent, flags, startId);
                }
                DownloadingTaskList.SINGLETON.setHandler(mHandler);
                DownloadingTaskList.SINGLETON.addNewDownloadTask(url);
            }
        }

        return super.onStartCommand(intent, flags, startId);

    }

    private void initNotification() {
        mNotifyManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Intent mainIntent = new Intent(Intent.ACTION_MAIN);
        mainIntent.setComponent(new ComponentName(this, MainActivity.class));
        PendingIntent disconnectPendingIntent = PendingIntent.getActivity(this, 0, mainIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT), 0);
        mBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_SERVICE);
        mBuilder.setWhen(0);
        mBuilder.setColor(ContextCompat.getColor(this, R.color.black)).setContentIntent(disconnectPendingIntent)
                .setSmallIcon(R.drawable.ins_icon);
        mBuilder.setPriority(NotificationCompat.PRIORITY_LOW);
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    private void setNotificationContent(String pageURL, String contentTitle) {
        mBuilder.setContentTitle(contentTitle)
                .setContentText(pageURL)
                .setSmallIcon(R.drawable.ins_icon);
        // PROGRESS_CURRENT = 0;
        // mBuilder.setProgress(PROGRESS_MAX, PROGRESS_CURRENT, false);
        mNotifyManager.notify(pageURL.hashCode(), mBuilder.build());
        startForeground(pageURL.hashCode(), mBuilder.build());
    }


    final static int PROGRESS_MAX = 100;
    static int PROGRESS_CURRENT = 0;
    private int mProgress = PROGRESS_CURRENT;

    private void updateNotificationProgress(String pageURL, int progress) {
        // Displays the progress bar for the first time.
        if (PROGRESS_CURRENT != progress) {
            if (progress == 100) {
                mBuilder.setContentText("Download complete")
                        .setProgress(0, 0, false);
                mNotifyManager.notify(pageURL.hashCode(), mBuilder.build());
            } else {
                mBuilder.setProgress(100, progress, false);
                mNotifyManager.notify(pageURL.hashCode(), mBuilder.build());
                PROGRESS_CURRENT = progress;
            }
        }

    }

    private void cancelNotification(String pageURL) {
        mNotifyManager.cancel(pageURL.hashCode());
        if (DownloadingTaskList.SINGLETON.isEmpty()) {
            stopForeground(true);
        }
    }


    private void cancelAllNotification() {
        mNotifyManager.cancelAll();
    }



    public void publishProgress(String pageURL, int filePosition, int progress) {
        notifyDownloadProgress(pageURL, filePosition, progress);
    }

    private Object sCallbackLock = new Object();

    private void notifyDownloadProgress(String pageUrl, int filePosition, int progress) {
        try {
            synchronized (sCallbackLock) {
                if (mCallbacks.getRegisteredCallbackCount() > 0) {
                    final int N = mCallbacks.beginBroadcast();
                    for (int i = 0; i < N; i++) {
                        try {
                            mCallbacks.getBroadcastItem(i).onPublishProgress(pageUrl, filePosition, progress);
                        } catch (RemoteException e) {
                            // The RemoteCallbackList will take care of removing
                            // the dead object for us.
                        }
                    }
                    mCallbacks.finishBroadcast();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void notifyReceiveNewTask(String pageURL) {
        try {
            synchronized (sCallbackLock) {
                if (mCallbacks.getRegisteredCallbackCount() > 0) {
                    final int N = mCallbacks.beginBroadcast();
                    for (int i = 0; i < N; i++) {
                        try {
                            mCallbacks.getBroadcastItem(i).onReceiveNewTask(pageURL);
                        } catch (RemoteException e) {
                            // The RemoteCallbackList will take care of removing
                            // the dead object for us.
                        }
                    }
                    mCallbacks.finishBroadcast();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    private void notifyStartDownload(String filePath) {
        try {
            if (mCallbacks.getRegisteredCallbackCount() > 0) {
                final int N = mCallbacks.beginBroadcast();
                for (int i = 0; i < N; i++) {
                    try {
                        mCallbacks.getBroadcastItem(i).onStartDownload(filePath);
                    } catch (RemoteException e) {
                        // The RemoteCallbackList will take care of removing
                        // the dead object for us.
                    }
                }
                mCallbacks.finishBroadcast();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void notifyDownloadFinished(String filePath) {

        try {
            if (mCallbacks.getRegisteredCallbackCount() > 0) {
                final int N = mCallbacks.beginBroadcast();
                for (int i = 0; i < N; i++) {
                    try {
                        mCallbacks.getBroadcastItem(i).onDownloadSuccess(filePath);
                    } catch (RemoteException e) {
                        // The RemoteCallbackList will take care of removing
                        // the dead object for us.
                    }
                }
                mCallbacks.finishBroadcast();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }


    private final IDownloadBinder.Stub mBinder = new IDownloadBinder.Stub() {
        @Override
        public void registerCallback(IDownloadCallback callback) throws RemoteException {
            mCallbacks.register(callback);
        }

        @Override
        public void unregisterCallback(IDownloadCallback callback) throws RemoteException {
            mCallbacks.unregister(callback);
        }
    };
}
