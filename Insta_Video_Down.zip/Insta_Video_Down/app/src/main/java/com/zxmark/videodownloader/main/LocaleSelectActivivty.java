package com.zxmark.videodownloader.main;

import android.app.Activity;

/**
 * Created by fanlitao on 6/18/17.
 */

public class LocaleSelectActivivty extends Activity {
}
