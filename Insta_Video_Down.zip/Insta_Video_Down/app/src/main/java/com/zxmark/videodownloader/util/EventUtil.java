package com.zxmark.videodownloader.util;

import android.os.Bundle;

public class EventUtil {


    private static final EventUtil sInstance = new EventUtil();

    public static EventUtil getDefault() {
        return sInstance;
    }



    public void onEvent(String key,String tag) {
        Bundle params = new Bundle();
        params.putString("tag", tag);
    }
}
