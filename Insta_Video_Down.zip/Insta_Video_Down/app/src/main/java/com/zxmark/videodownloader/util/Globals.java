package com.zxmark.videodownloader.util;

/**
 * Created by fanlitao on 17/6/8.
 */

public class Globals {


    public static final String ACTION_CHANGE_LOCALE = "action_change_locale";
    public static final String EXTRAS = "extras";
    public static final boolean TEST_FOR_GP  = false;

    public static final String ACTION_NOTIFY_DATA_CHANGED = "action_data_changed";
    public static final String KEY_BEAN_PAGE_URL = "KEY_BEAN_PAGE_URL";
}
