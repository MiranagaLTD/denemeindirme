package com.zxmark.videodownloader;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by fanlitao on 6/21/17.
 */

public class BaseActivity extends AppCompatActivity {
}
