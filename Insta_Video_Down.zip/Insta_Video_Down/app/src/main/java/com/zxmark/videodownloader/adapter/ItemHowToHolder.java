package com.zxmark.videodownloader.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by fanlitao on 6/16/17.
 */

public class ItemHowToHolder  extends RecyclerView.ViewHolder{


    public ItemHowToHolder(View itemView) {
        super(itemView);
    }
}
