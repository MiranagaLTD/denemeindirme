package org.schabi.newpipe;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivitySplash extends AppCompatActivity {


    String reklam_gorsel;
    String reklam_link;

    HashMap<String, String> url_maps;
    String ResultJson;

    ImageView img_view;
    ImageView img_view1;
    RelativeLayout reklamSayfasi;

    List<String> rek_link = new ArrayList<String>();
    List<String> rek_name = new ArrayList<String>();

    private TextView mTitle;
    private AlphaAnimation fadeOut;
    RelativeLayout guncelle;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        fadeOut = new AlphaAnimation(0.0f, 1.0f);
        mTitle = (TextView)findViewById(R.id.title);

        mTitle.startAnimation(fadeOut);
        fadeOut.setDuration(3000);
        fadeOut.setFillAfter(true);

        reklamSayfasi = (RelativeLayout)findViewById(R.id.reklamsayfa);
        guncelle = (RelativeLayout)findViewById(R.id.layotguncelle);

        img_view = (ImageView)findViewById(R.id.imageguncelle);
        img_view1 = (ImageView)findViewById(R.id.imagearka1);
        img_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ireklam = new Intent(Intent.ACTION_VIEW);
                ireklam.setData(Uri.parse(reklam_link));
                startActivity(ireklam);

            }
        });

        new JsonTask().execute("http://miranaga.com/services/mrsl.php");
    }

    private void gecisYap() {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }


    public Bitmap getBitmapfromUrl(String imageUrl)
    {
        try
        {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;

        } catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;

        }
    }

    public void ReklamInit(){

        img_view.setImageBitmap(getBitmapfromUrl(reklam_gorsel));
        img_view1.setImageBitmap(getBitmapfromUrl(reklam_gorsel));



    }



    private class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();


        }

        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";


                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                    ResultJson = line;

                }

                if (ResultJson == null || ResultJson.equals("") || ResultJson.equals("no results found")) {
                    // reklam gelmezse
                    guncelle.setVisibility(View.INVISIBLE);
                    reklamSayfasi.setVisibility(View.INVISIBLE);

                } else {
                    JSONArray json = new JSONArray(ResultJson);
                    url_maps = new HashMap<String, String>();

                    for (int i = 0; i < json.length(); i++) {

                        JSONObject e = json.getJSONObject(i);

                        reklam_gorsel = e.getString("rek_image").toString();
                        reklam_link = e.getString("rek_link").toString();
                        url_maps.put(e.getString("rek_description").toString(), e.getString("rek_image").toString());
                        rek_link.add(e.getString("rek_link").toString());
                        rek_name.add(e.getString("rek_description").toString());

                        // startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(reklam_link)));
                        //Intent i1 = new Intent(getBaseContext(), MainActivity.class);


                    }

                }
                return buffer.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            if (ResultJson == null || ResultJson.equals("no results found")) {
                // reklam yoksa
                guncelle.setVisibility(View.INVISIBLE);
                reklamSayfasi.setVisibility(View.INVISIBLE);
                gecisYap();

            } else {
                new DownLoadImageTask(img_view).execute(reklam_gorsel);
                new DownLoadImageTask(img_view1).execute(reklam_gorsel);
                // reklam gelince
                guncelle.setVisibility(View.VISIBLE);
                reklamSayfasi.setVisibility(View.VISIBLE);
                ReklamInit();

            }
        }
    }


    private class DownLoadImageTask extends AsyncTask<String,Void,Bitmap> {
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView){
            this.imageView = imageView;
        }

        protected Bitmap doInBackground(String...urls){
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try{
                InputStream is = new URL(urlOfImage).openStream();
                logo = BitmapFactory.decodeStream(is);
            }catch(Exception e){ // Catch the download exception
                e.printStackTrace();
            }
            return logo;
        }

        protected void onPostExecute(Bitmap result){
            imageView.setImageBitmap(result);
        }
    }


}
