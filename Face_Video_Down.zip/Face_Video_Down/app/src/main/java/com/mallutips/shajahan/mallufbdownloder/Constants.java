package com.mallutips.shajahan.mallufbdownloder;

/**
 * Created by Tushar on 9/7/2017.
 */

class Constants {
    public static final String FOLDER_NAME ="/FBDownloader/";
    public static String MyPREFERENCES = "PREFS";
}
